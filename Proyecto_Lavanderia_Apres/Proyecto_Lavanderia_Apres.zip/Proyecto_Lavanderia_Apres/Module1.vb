﻿Module Module1
    Public miconexion As New System.Data.OleDb.OleDbConnection
    Public ultimoRegistro As String
    Public nombreUsuario As String

End Module
